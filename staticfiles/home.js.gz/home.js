document.querySelector("#toChat").onclick = function() {
  window.location.pathname = "chat/";
}

document.querySelector("#toInstructions").onclick = function() {
  window.location.pathname = "instructions/"
}

document.querySelector("#toDonation").onclick = function() {
  window.location.pathname = "donations/"
}
